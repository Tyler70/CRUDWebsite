<HTML>
    <head></head><body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form

        //mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "tylerm";
    $mysql_password = "soccer70";
    $mysql_database = "movies";

    $item = $_POST["update"];


    $conn = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

        $sql = "SELECT * FROM movie_info WHERE MovieTitle='" . $_POST['update'] . "'";
        $result = $conn->query($sql);

        $MovieTitle = $row[0];
        $MovieDate= $row[1];
        $Showtime = $row[2];
// HTML to display the form on this page.
                     echo "<form action='changeItem.php' method = 'post'>";
                     echo "<TD><input type='text' placeholder='Movie Title' name='MovieTitle' Division='advancedSearchTextBox'></TD>";
                     echo  "<input type='text' placeholder='MovieDate' name='MovieDate'>";
                     echo  "<input type='text' placeholder='Showtime' name='Showtime'>";
                        echo "<input name = 'create' type = 'submit' value = 'Submit Changes'>";
                        echo "</form>";


                    } 
                 echo "</body>"; 

?>
