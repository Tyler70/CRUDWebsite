<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
    $mysql_host = "localhost";
    $mysql_username = "tylerm";
    $mysql_password = "soccer70";
    $mysql_database = "movies";
    
    
	$movieTitle = $_POST["MovieTitle"];
	$Showtime = $_POST["Showtime"];
	$movieDate = $_POST["MovieDate"];
	

	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	//Output any connection error
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	
		$statement = $mysqli->prepare("INSERT INTO movie_info (MovieTitle, Showtime, MovieDate) VALUES(?, ?, ?)"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param('sss', $movieTitle, $Showtime, $movieDate); //bind value
		if($statement->execute())
			{
				//print output text
				echo nl2br("The movie"." ". $movieTitle . " has been added at ". $Showtime.  "\r\non ". $movieDate ." in May.", false);
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}
echo"<br><form action= 'update_delete.php' method = 'get'>";
echo "<input name = 'action'   type = 'submit' value = 'Go Back'></form>";
         }
else{
    echo ("error");
    }         
?>