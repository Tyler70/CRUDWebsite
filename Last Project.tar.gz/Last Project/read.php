<?php
    $dbhost = 'localhost';
    $dbuser = 'tylerm';
    $dbpass = 'soccer70';
    
    $conn = mysql_connect($dbhost, $dbuser, $dbpass);
    
    if(! $conn ) {
        die('Could not connect: ' . mysql_error());
    }
    
    $sql = 'SELECT * FROM movie_info';
    mysql_select_db('movies');
    $retval = mysql_query( $sql, $conn );
    
     if(! $retval ) {
        die('Could not get data: ' . mysql_error());
    }
    
$MovieTitle = $row[0];
$MovieDate = $row[1];
$Showtime = $row[2];

    while($row = mysql_fetch_assoc($retval)) {
        // The following few lines store info from specific cells
        echo "<TR>";
			echo "<TD>MovieTitle: ".$row['MovieTitle']. " MovieDate: ". $row['MovieDate']. " Showtime: ".$row['Showtime'] ."</TD>";
			echo "<TD><form action= 'update.php' method = 'post'>";
			echo "<button name = 'update'   type = 'submit' value =".$row['MovieTitle'].">Edit</button></FORM>";
			echo "<TD><form action= 'delete.php' method = 'post'>";
			echo "<button name = 'delete'   type = 'submit' value =".$row['MovieTitle'].">Delete</button></FORM>";
			echo "</TR>";
    }
    
    echo "Fetched data seuccessfully\n";
    
    mysql_close($conn);
    
?>
<link href="styles.css" rel="stylesheet" type="text/css">