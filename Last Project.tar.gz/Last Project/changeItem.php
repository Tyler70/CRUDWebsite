<HTML>
    <HEAD> <link rel='stylesheet' href='styles.css'></HEAD><BODY>";
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST")	//Check it is coming from a form
    {
        require_once 'login1.php';				//mysql credentials

	    //delcare PHP variables
	    $MovieTitle = $_POST["MovieTitle"];
	    $MovieDate = $_POST["MovieDate"];			//The values in the $_POST must match the names given from the HTML document
	    $Showtime = $_POST["Showtime"];

	    
        $mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
        if ($mysqli->connect_error) 
            {
		        die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	        }   
        if ($_POST['MovieTitle']!= "")
            {
                
	
		$statement = $mysqli->prepare("UPDATE movie_info SET MovieTitle= ?, MovieDate=?, Showtime = ?"); //prepare sql insert query - thank you(https://stackoverflow.com/questions/6514649/php-mysql-bind-param-how-to-prepare-statement-for-update-query)
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param('sss', $MovieTitle, $MovieDate, $Showtime); //bind value
		if($statement->execute())
			{
				//print output text
				echo nl2br("You have updated "." ". $MovieTitle . "'s information to\r\n May " . $MovieDate." ". $Showtime .".", false);
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}
                
            }
        echo" ";
    }
echo"<br><form action= 'back_button.php' method = 'get'>";
echo "<input name = 'action'   type = 'submit' value = 'Go Back'></form></body>";
?>