<?php
    $mysql_host = "localhost";
    $mysql_username = "tylerm";
    $mysql_password = "soccer70";
    $mysql_database = "movies";
?>
